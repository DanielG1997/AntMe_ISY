#include "application.hpp"

int main(int argc, char** argv) {
  Application app;
  return app.Run();
}
